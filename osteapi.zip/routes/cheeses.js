const Service = require('../services/cheeses');

module.exports = (server) => {
	server.get('/cheeses', (req, res) => {
		Service.getAll((err, result) => {
			if (err) {
				res.status(500);
				res.end();
			} else {
				res.send(result);
			}
		});
	});

	server.get('/cheeses/:varenr', (req, res) => {
		Service.getOne(req.params.varenr, (err, result) => {
			if (err) {
				res.status(500);
				res.end();
			} else {
				res.send(result);
			}
		});
	});
};